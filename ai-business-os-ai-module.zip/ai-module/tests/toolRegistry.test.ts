import { getToolDefinition, TOOL_DEFINITIONS, toClaudeToolFormat } from '../src/services/tools/toolRegistry';

describe('toolRegistry', () => {
  it('contains all tools required by the spec', () => {
    const names = TOOL_DEFINITIONS.map((t) => t.name);
    expect(names).toEqual(
      expect.arrayContaining([
        'generate_quotation',
        'generate_proposal',
        'generate_invoice',
        'generate_report',
        'generate_maintenance_schedule',
        'summarize_document',
        'search_company_knowledge',
        'create_task',
        'schedule_meeting',
      ])
    );
  });

  it('restricts generate_invoice to elevated roles', () => {
    const invoiceTool = getToolDefinition('generate_invoice');
    expect(invoiceTool?.allowedRoles).toEqual(expect.arrayContaining(['owner', 'manager', 'billing']));
  });

  it('translates internal schema into valid Claude tool format', () => {
    const claudeTools = toClaudeToolFormat();
    const quotationTool = claudeTools.find((t) => t.name === 'generate_quotation');
    expect(quotationTool).toBeDefined();
    expect(quotationTool?.input_schema.type).toBe('object');
    expect(quotationTool?.input_schema.required).toContain('items');
  });

  it('returns undefined for unknown tool names', () => {
    expect(getToolDefinition('delete_all_data')).toBeUndefined();
  });
});
