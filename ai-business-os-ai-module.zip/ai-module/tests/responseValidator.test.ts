import { validateResponse } from '../src/services/validation/responseValidator';
import { RetrievedChunk } from '../src/types';

function chunk(text: string): RetrievedChunk {
  return {
    chunkId: 'c1',
    documentId: 'd1',
    companyId: 'company-a',
    text,
    order: 0,
    metadata: {},
    score: 0.9,
  };
}

describe('responseValidator', () => {
  it('passes when a cited price appears in retrieved context', () => {
    const chunks = [chunk('Consulting is priced at $100 per hour.')];
    const result = validateResponse('Consulting costs $100 per hour.', chunks, true);
    expect(result.passed).toBe(true);
  });

  it('flags a fabricated price not present in context', () => {
    const chunks = [chunk('Consulting is priced at $100 per hour.')];
    const result = validateResponse('Consulting costs $9999 per hour.', chunks, true);
    expect(result.passed).toBe(false);
    expect(result.issues.some((i) => i.type === 'fabricated_price')).toBe(true);
  });

  it('flags a confident company claim made with zero retrieved context', () => {
    const result = validateResponse('Our policy is that all sales are final.', [], false);
    expect(result.passed).toBe(false);
    expect(result.issues.some((i) => i.type === 'unsupported_claim')).toBe(true);
  });

  it('does not flag generic responses with no numeric claims', () => {
    const result = validateResponse("I don't have that information available.", [], false);
    expect(result.passed).toBe(true);
  });
});
