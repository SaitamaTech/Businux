import { ToolExecutor, UnauthorizedToolCallError } from '../src/services/tools/toolExecutor';
import { CompanyDataClient, BusinessLogicClient } from '../src/api/externalClients';
import { RagService } from '../src/services/rag/ragService';
import { EmbeddingService } from '../src/services/embeddings/embeddingService';
import { InMemoryVectorStore } from '../src/services/vectorStore/vectorStore';

const mockCompanyDataClient: CompanyDataClient = {
  getCompanyProfile: jest.fn().mockResolvedValue({ companyId: 'company-a', name: 'Acme' }),
  getPricingCatalog: jest.fn().mockResolvedValue([
    { sku: 'consulting-hour', name: 'Consulting Hour', unitPrice: 100, currency: 'USD' },
  ]),
  getCustomer: jest.fn().mockResolvedValue({ customerId: 'cust-1', name: 'Jane Doe' }),
  saveGeneratedDocument: jest.fn().mockResolvedValue({ id: 'doc-1' }),
};

const mockBusinessLogicClient: BusinessLogicClient = {
  createTask: jest.fn().mockResolvedValue({ id: 'task-1' }),
  scheduleMeeting: jest.fn().mockResolvedValue({ id: 'meeting-1' }),
  createInvoiceRecord: jest.fn().mockResolvedValue({ id: 'inv-1', number: 'INV-001' }),
};

function makeExecutor() {
  const ragService = new RagService(new EmbeddingService(), new InMemoryVectorStore());
  return new ToolExecutor({
    companyDataClient: mockCompanyDataClient,
    businessLogicClient: mockBusinessLogicClient,
    ragService,
  });
}

describe('ToolExecutor', () => {
  it('executes generate_quotation successfully when pricing exists', async () => {
    const executor = makeExecutor();
    const result = await executor.execute(
      'generate_quotation',
      { items: [{ sku: 'consulting-hour', quantity: 3 }] },
      { auth: { userId: 'u1', companyId: 'company-a', userRole: 'staff' }, conversationId: 'c1' }
    );
    expect(result.success).toBe(true);
  });

  it('fails generate_quotation gracefully when item is not in catalog (never fabricates price)', async () => {
    const executor = makeExecutor();
    const result = await executor.execute(
      'generate_quotation',
      { items: [{ sku: 'nonexistent-item', quantity: 1 }] },
      { auth: { userId: 'u1', companyId: 'company-a', userRole: 'staff' }, conversationId: 'c1' }
    );
    expect(result.success).toBe(false);
  });

  it('throws UnauthorizedToolCallError for generate_invoice when role lacks permission', async () => {
    const executor = makeExecutor();
    await expect(
      executor.execute(
        'generate_invoice',
        { customerId: 'cust-1', items: [{ sku: 'consulting-hour', quantity: 1 }] },
        { auth: { userId: 'u1', companyId: 'company-a', userRole: 'staff' }, conversationId: 'c1' }
      )
    ).rejects.toThrow(UnauthorizedToolCallError);
  });

  it('allows generate_invoice for an authorized role', async () => {
    const executor = makeExecutor();
    const result = await executor.execute(
      'generate_invoice',
      { customerId: 'cust-1', items: [{ sku: 'consulting-hour', quantity: 1 }] },
      { auth: { userId: 'u1', companyId: 'company-a', userRole: 'owner' }, conversationId: 'c1' }
    );
    expect(result.success).toBe(true);
  });

  it('returns a failure result for an unknown tool name', async () => {
    const executor = makeExecutor();
    const result = await executor.execute(
      'delete_all_customers',
      {},
      { auth: { userId: 'u1', companyId: 'company-a', userRole: 'owner' }, conversationId: 'c1' }
    );
    expect(result.success).toBe(false);
  });
});
