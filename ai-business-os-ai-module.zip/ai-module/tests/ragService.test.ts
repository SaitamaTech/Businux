import { RagService } from '../src/services/rag/ragService';
import { EmbeddingService } from '../src/services/embeddings/embeddingService';
import { InMemoryVectorStore } from '../src/services/vectorStore/vectorStore';
import { DocumentChunk } from '../src/types';

function makeChunk(companyId: string, text: string, order = 0): DocumentChunk {
  return {
    chunkId: `${companyId}-${order}-${Math.random()}`,
    documentId: `doc-${companyId}`,
    companyId,
    text,
    order,
    metadata: { fileName: 'test.txt' },
  };
}

describe('RagService', () => {
  it('retrieves relevant chunks for a company', async () => {
    const embeddingService = new EmbeddingService();
    const vectorStore = new InMemoryVectorStore();
    const rag = new RagService(embeddingService, vectorStore);

    await rag.ingestChunks([
      makeChunk('company-a', 'Our refund policy allows returns within 30 days.'),
      makeChunk('company-a', 'We are located in Lagos, Nigeria.'),
    ]);

    const result = await rag.retrieve('company-a', 'What is the refund policy?');
    expect(result.chunks.length).toBeGreaterThan(0);
    expect(result.contextText.length).toBeGreaterThan(0);
  });

  it('never returns another company\'s chunks (multi-tenant isolation)', async () => {
    const embeddingService = new EmbeddingService();
    const vectorStore = new InMemoryVectorStore();
    const rag = new RagService(embeddingService, vectorStore);

    await rag.ingestChunks([makeChunk('company-a', 'Company A secret pricing is $500.')]);
    await rag.ingestChunks([makeChunk('company-b', 'Company B secret pricing is $999.')]);

    const resultForB = await rag.retrieve('company-b', 'What is the pricing?');
    for (const chunk of resultForB.chunks) {
      expect(chunk.companyId).toBe('company-b');
    }
  });

  it('flags insufficient context when nothing relevant is stored', async () => {
    const embeddingService = new EmbeddingService();
    const vectorStore = new InMemoryVectorStore();
    const rag = new RagService(embeddingService, vectorStore);

    const result = await rag.retrieve('company-empty', 'anything at all');
    expect(result.hasSufficientContext).toBe(false);
  });
});
