import { chunkText, cleanText } from '../src/services/documentProcessing/documentProcessor';

describe('documentProcessor', () => {
  describe('cleanText', () => {
    it('normalizes line endings and collapses whitespace', () => {
      const dirty = 'Hello\r\nWorld\n\n\n\nFoo   Bar\t\tBaz';
      const cleaned = cleanText(dirty);
      expect(cleaned).not.toContain('\r');
      expect(cleaned).not.toMatch(/\n{3,}/);
      expect(cleaned).toContain('Foo Bar Baz');
    });
  });

  describe('chunkText', () => {
    it('keeps short text as a single chunk', () => {
      const text = 'This is a short paragraph.';
      const chunks = chunkText(text, 800, 120);
      expect(chunks.length).toBe(1);
      expect(chunks[0]).toBe(text);
    });

    it('splits long text into multiple chunks respecting chunk size', () => {
      const paragraph = 'Sentence about company policy. '.repeat(50); // long single paragraph
      const chunks = chunkText(paragraph, 200, 30);
      expect(chunks.length).toBeGreaterThan(1);
      for (const chunk of chunks) {
        expect(chunk.length).toBeLessThanOrEqual(220); // allow small overlap slack
      }
    });

    it('does not produce empty chunks', () => {
      const text = '\n\n\nParagraph one.\n\n\nParagraph two.\n\n\n';
      const chunks = chunkText(cleanText(text), 800, 120);
      for (const chunk of chunks) {
        expect(chunk.trim().length).toBeGreaterThan(0);
      }
    });
  });
});
