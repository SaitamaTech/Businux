import { EmbeddingService, cosineSimilarity } from '../src/services/embeddings/embeddingService';

describe('EmbeddingService (local-mock provider)', () => {
  it('produces deterministic embeddings for identical text', async () => {
    const service = new EmbeddingService();
    const [a] = await service.embedTexts(['hello world']);
    const [b] = await service.embedTexts(['hello world']);
    expect(a).toEqual(b);
  });

  it('produces different embeddings for different text', async () => {
    const service = new EmbeddingService();
    const [a] = await service.embedTexts(['refund policy']);
    const [b] = await service.embedTexts(['completely unrelated text about rockets']);
    expect(a).not.toEqual(b);
  });

  it('embedQuery matches embedTexts output for the same text', async () => {
    const service = new EmbeddingService();
    const queryEmbedding = await service.embedQuery('pricing');
    const [batchEmbedding] = await service.embedTexts(['pricing']);
    expect(queryEmbedding).toEqual(batchEmbedding);
  });
});

describe('cosineSimilarity', () => {
  it('returns 1 for identical vectors', () => {
    const v = [1, 2, 3];
    expect(cosineSimilarity(v, v)).toBeCloseTo(1, 5);
  });

  it('returns 0 for orthogonal vectors', () => {
    expect(cosineSimilarity([1, 0], [0, 1])).toBeCloseTo(0, 5);
  });

  it('returns 0 when a vector is all zeros', () => {
    expect(cosineSimilarity([0, 0], [1, 1])).toBe(0);
  });
});
