import { MemoryManager } from '../src/services/memory/memoryManager';

describe('MemoryManager', () => {
  it('creates a new conversation if none exists', async () => {
    const manager = new MemoryManager();
    const state = await manager.getOrCreate('conv-1', 'company-a', 'user-1');
    expect(state.conversationId).toBe('conv-1');
    expect(state.messages).toHaveLength(0);
  });

  it('appends messages and preserves order', async () => {
    const manager = new MemoryManager();
    let state = await manager.getOrCreate('conv-2', 'company-a', 'user-1');
    state = await manager.appendMessage(state, {
      role: 'user',
      content: 'Generate a quotation',
      timestamp: new Date().toISOString(),
    });
    state = await manager.appendMessage(state, {
      role: 'assistant',
      content: 'Sure, here is the quotation...',
      timestamp: new Date().toISOString(),
    });
    expect(state.messages.map((m) => m.role)).toEqual(['user', 'assistant']);
  });

  it('stores working memory that later turns can reference', async () => {
    const manager = new MemoryManager();
    let state = await manager.getOrCreate('conv-3', 'company-a', 'user-1');
    state = await manager.setWorkingMemory(state, 'lastQuotation', { total: 500 });
    expect(state.workingMemory.lastQuotation).toEqual({ total: 500 });
  });

  it('throws if the same conversationId is reused across companies', async () => {
    const manager = new MemoryManager();
    await manager.getOrCreate('conv-shared', 'company-a', 'user-1');
    await expect(manager.getOrCreate('conv-shared', 'company-b', 'user-2')).rejects.toThrow(
      /cross-tenant/i
    );
  });

  it('bounds recent messages to the sliding window', async () => {
    const manager = new MemoryManager();
    let state = await manager.getOrCreate('conv-4', 'company-a', 'user-1');
    for (let i = 0; i < 30; i++) {
      state = await manager.appendMessage(state, {
        role: i % 2 === 0 ? 'user' : 'assistant',
        content: `message ${i}`,
        timestamp: new Date().toISOString(),
      });
    }
    const recent = manager.getRecentMessages(state, 20);
    expect(recent).toHaveLength(20);
    expect(recent[recent.length - 1].content).toBe('message 29');
  });
});
