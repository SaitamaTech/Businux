# AI Business OS — AI Module (Member 3 scope)

This is **only** the AI / intelligence layer of the AI Business Operating System.
It does not include frontend, authentication, database schema, dashboard, or
other members' business logic — those are assumed to exist, and this module
talks to them only through the typed contracts in `src/api/contracts.md` and
`src/api/externalClients.ts`.

## What this module does

- Exposes `POST /api/chat` — the single entry point another backend developer calls.
- Exposes `POST /api/documents/ingest` — called after a file is uploaded elsewhere.
- Runs the full pipeline: auth context → conversation memory → RAG retrieval →
  prompt construction → tool-calling decision → tool execution → response
  generation → security scan → factual validation → return.
- Never invents company data (prices, policies, customer info, employee counts).
  If it can't find something, it says so.
- Isolates every operation (vector search, memory, tool calls) by `companyId`.

## Project structure

```
src/
  api/            # /api/chat, /api/documents/ingest + contracts with other modules
  config/         # env-driven configuration
  prompts/        # system prompt + prompt builder
  services/
    chat/         # orchestration (chatService) + LLM client wrapper
    documentProcessing/  # extract/clean/chunk PDF, DOCX, TXT, MD
    embeddings/   # pluggable embedding provider (OpenAI / mock)
    memory/       # conversation memory manager
    rag/          # retrieval-augmented generation
    security/     # prompt-injection defense, leakage checks, tenant isolation
    tools/        # tool registry, executor, and individual tool implementations
    validation/   # post-generation factual-consistency checks
    vectorStore/  # pluggable vector store (in-memory now; swap in Pinecone/pgvector later)
  types/          # shared TypeScript types / contracts
tests/            # jest unit tests for every service above
```

## Setup

```bash
npm install
cp .env.example .env   # fill in ANTHROPIC_API_KEY at minimum
npm run dev             # starts the API on PORT (default 4000)
```

Without `EMBEDDING_PROVIDER=openai` + a key, embeddings fall back to a local
deterministic mock so the whole RAG pipeline (chunk → embed → store → search)
still works end-to-end for demos/tests without any external key.

Without the other modules' base URLs set (`AUTH_SERVICE_BASE_URL`,
`DB_SERVICE_BASE_URL`, `BUSINESS_LOGIC_SERVICE_BASE_URL`), calls to those
clients throw a clear `NotImplementedByAIModuleError` rather than silently
returning fake data — this makes integration gaps obvious during the demo.

## Testing

```bash
npm test
```

40 unit tests cover prompt building blocks, chunking, embeddings, RAG
retrieval + multi-tenant isolation, memory, tool registry/executor +
permission checks, response validation (fabrication rejection), and security
middleware (prompt injection / leakage detection).

## Security model (summary)

- **Structural** (primary defense): the system prompt and retrieved document
  context are always kept in separate, clearly labeled prompt regions, so the
  model is instructed to treat retrieved text as data, never as commands —
  this is what actually stops indirect prompt injection from uploaded docs.
- **Heuristic** (defense in depth): pattern-based scans on user input,
  retrieved context, and model output flag likely injection/leakage attempts
  for logging/monitoring.
- **Multi-tenancy**: the vector store partitions storage by `companyId` at the
  data-structure level, not just by query filter, and `assertSameCompany` is
  called before touching any conversation or tool result.
- **Tool permissions**: tools like `generate_invoice` declare `allowedRoles`;
  the executor throws `UnauthorizedToolCallError` before dispatch if the
  requesting user's role isn't listed.
- **No fabrication**: pricing/invoice tools query the (stubbed) company data
  client and fail explicitly if an item/customer isn't found; the response
  validator additionally scans generated text for prices/numbers not present
  in retrieved context and appends an uncertainty disclaimer if found.

## What's intentionally NOT here

Per the brief: no frontend, no auth implementation, no DB schema, no
dashboard, no other member's business logic. Everywhere the AI module needs
one of those, it calls a typed client interface documented in
`src/api/contracts.md` instead.
