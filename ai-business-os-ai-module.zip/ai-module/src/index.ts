import express from 'express';
import { config } from './config';
import { createRouter } from './api/router';
import {
  HttpAuthClient,
  HttpBusinessLogicClient,
  HttpCompanyDataClient,
} from './api/externalClients';
import { EmbeddingService } from './services/embeddings/embeddingService';
import { createVectorStore } from './services/vectorStore/vectorStore';
import { RagService } from './services/rag/ragService';
import { MemoryManager } from './services/memory/memoryManager';
import { ToolExecutor } from './services/tools/toolExecutor';
import { LlmClient } from './services/chat/llmClient';
import { ChatService } from './services/chat/chatService';

function bootstrap() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // --- Wire dependencies (composition root) ---
  const embeddingService = new EmbeddingService();
  const vectorStore = createVectorStore();
  const ragService = new RagService(embeddingService, vectorStore);

  const authClient = new HttpAuthClient();
  const companyDataClient = new HttpCompanyDataClient();
  const businessLogicClient = new HttpBusinessLogicClient();

  const memoryManager = new MemoryManager();
  const toolExecutor = new ToolExecutor({ companyDataClient, businessLogicClient, ragService });
  const llmClient = new LlmClient();

  const chatService = new ChatService({
    authClient,
    companyDataClient,
    ragService,
    memoryManager,
    toolExecutor,
    llmClient,
  });

  app.use(createRouter(chatService, ragService));

  app.listen(config.server.port, () => {
    // eslint-disable-next-line no-console
    console.log(`AI module listening on port ${config.server.port} (${config.server.env})`);
  });
}

bootstrap();
