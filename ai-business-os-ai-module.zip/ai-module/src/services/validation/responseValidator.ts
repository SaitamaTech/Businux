/**
 * Response validator. Runs after the LLM generates a response, before it's
 * returned to the user. Heuristic-based (a hackathon-appropriate approach —
 * a production system might add a second LLM call as a "judge" for deeper
 * factual-consistency checks; that hook is left in `deepValidate` below).
 *
 * Checks for:
 *  - Numbers/prices in the response that don't appear anywhere in the
 *    retrieved context (possible fabrication)
 *  - Claims of certainty ("the price is", "our policy is") when no context
 *    was retrieved at all
 */

import { RetrievedChunk, ValidationIssue, ValidationResult } from '../../types';

const PRICE_PATTERN = /(\$|USD|EUR|£|€)\s?[\d,]+(\.\d{1,2})?/g;
const NUMBER_PATTERN = /\b\d{2,}(\.\d+)?\b/g;
const CONFIDENT_CLAIM_PATTERNS = [
  /our (policy|price|pricing|rate) is/i,
  /we (charge|offer|guarantee)/i,
  /the (price|cost|fee) (is|for)/i,
  /we have \d+ employees/i,
];

function extractNumericTokens(text: string, pattern: RegExp): string[] {
  return Array.from(text.matchAll(pattern)).map((m) => m[0]);
}

export function validateResponse(
  response: string,
  retrievedChunks: RetrievedChunk[],
  hadAnyContext: boolean
): ValidationResult {
  const issues: ValidationIssue[] = [];
  const contextText = retrievedChunks.map((c) => c.text).join(' ');

  // 1. Prices mentioned but not backed by context
  const pricesInResponse = extractNumericTokens(response, PRICE_PATTERN);
  for (const price of pricesInResponse) {
    if (!contextText.includes(price.replace(/\s/g, '')) && !contextText.includes(price)) {
      issues.push({
        type: 'fabricated_price',
        detail: `Response contains a price ("${price}") not found in retrieved company context.`,
      });
    }
  }

  // 2. Confident company claims with zero retrieved context at all
  if (!hadAnyContext) {
    for (const pattern of CONFIDENT_CLAIM_PATTERNS) {
      if (pattern.test(response)) {
        issues.push({
          type: 'unsupported_claim',
          detail: `Response makes a confident company-specific claim ("${pattern}") with no retrieved context to support it.`,
        });
      }
    }
  }

  // 3. Numbers that look like employee counts / stats but aren't in context
  if (/\bemployees?\b/i.test(response)) {
    const numbers = extractNumericTokens(response, NUMBER_PATTERN);
    for (const num of numbers) {
      if (!contextText.includes(num)) {
        issues.push({
          type: 'fabricated_number',
          detail: `Response cites a number ("${num}") near "employees" not found in retrieved context.`,
        });
      }
    }
  }

  const passed = issues.length === 0;

  return {
    passed,
    issues,
    sanitizedResponse: passed
      ? response
      : appendUncertaintyDisclaimer(response, issues),
  };
}

function appendUncertaintyDisclaimer(response: string, issues: ValidationIssue[]): string {
  const disclaimer =
    '\n\n[Note: I flagged part of this answer as potentially unverified against our records — please confirm figures/prices above with a team member before relying on them.]';
  return response + disclaimer;
}

/**
 * Hook for a future, stronger validation pass using a second LLM call as a
 * fact-checking judge against the retrieved context. Not implemented in the
 * hackathon build to keep latency/cost down, but the interface is here so it
 * can be dropped in without changing callers.
 */
export async function deepValidate(
  _response: string,
  _retrievedChunks: RetrievedChunk[]
): Promise<ValidationResult> {
  throw new Error('deepValidate is not implemented in the hackathon build — see responseValidator.ts');
}
