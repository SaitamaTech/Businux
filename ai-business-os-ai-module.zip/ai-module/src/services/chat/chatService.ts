/**
 * Chat service — orchestrates the full pipeline described in the spec:
 *
 * receive message -> auth context -> company id -> conversation history ->
 * determine intent (implicit, via tool-use decision) -> search knowledge if
 * required -> retrieve chunks -> construct prompt -> decide on tool call ->
 * call tool if necessary -> generate final response -> validate -> return.
 */

import { AuthClient, CompanyDataClient, BusinessLogicClient } from '../../api/externalClients';
import { buildPrompt } from '../../prompts/promptBuilder';
import { MemoryManager } from '../memory/memoryManager';
import { RagService } from '../rag/ragService';
import {
  assertSameCompany,
  scanOutputForLeakage,
  scanRetrievedContext,
  scanUserInput,
} from '../security/securityMiddleware';
import { ToolExecutor, UnauthorizedToolCallError } from '../tools/toolExecutor';
import { validateResponse } from '../validation/responseValidator';
import { LlmClient } from './llmClient';
import {
  ChatRequest,
  ChatResponse,
  ConfidenceLevel,
  ResponseFlag,
  SourceReference,
  ToolCallRecord,
} from '../../types';
import { config } from '../../config';

export interface ChatServiceDeps {
  authClient: AuthClient;
  companyDataClient: CompanyDataClient;
  ragService: RagService;
  memoryManager: MemoryManager;
  toolExecutor: ToolExecutor;
  llmClient: LlmClient;
}

export class ChatService {
  constructor(private deps: ChatServiceDeps) {}

  async handleMessage(request: ChatRequest): Promise<ChatResponse> {
    const flags: ResponseFlag[] = [];

    // 1. Input hygiene / injection scan (structural defenses still apply downstream)
    const inputScan = scanUserInput(request.message);
    flags.push(...inputScan.flags);
    const userMessage = inputScan.sanitizedInput ?? request.message;

    // 2. Resolve authenticated context (auth module's job; we just consume it)
    const auth = await this.deps.authClient.getUserContext(request.userId, request.companyId);
    assertSameCompany(request.companyId, auth.companyId);

    // 3. Load/create conversation memory, scoped to this company
    let conversation = await this.deps.memoryManager.getOrCreate(
      request.conversationId,
      request.companyId,
      request.userId
    );
    conversation = await this.deps.memoryManager.appendMessage(conversation, {
      role: 'user',
      content: userMessage,
      timestamp: new Date().toISOString(),
    });

    // 4. Retrieve company knowledge relevant to this message
    const ragResult = await this.deps.ragService.retrieve(request.companyId, userMessage);
    const contextScan = scanRetrievedContext(ragResult.contextText);
    flags.push(...contextScan.flags);
    if (!ragResult.hasSufficientContext) flags.push('no_knowledge_found');

    // 5. Fetch company profile for prompt personalization (never fabricated —
    //    if unavailable, we just omit the name)
    let companyName: string | undefined;
    try {
      const profile = await this.deps.companyDataClient.getCompanyProfile(request.companyId);
      companyName = profile?.name;
    } catch {
      companyName = undefined; // DB module not wired yet in this hackathon build — degrade gracefully
    }

    // 6. Build the prompt
    const recentMessages = this.deps.memoryManager.getRecentMessages(conversation);
    const prompt = buildPrompt({
      companyName,
      recentMessages,
      ragContextText: ragResult.contextText,
      hasSufficientContext: ragResult.hasSufficientContext,
      currentUserMessage: userMessage,
    });

    // 7. Generate response, allowing the model to decide on tool calls
    const llmResponse = await this.deps.llmClient.generate(prompt.system, prompt.messages, true);

    const toolCallRecords: ToolCallRecord[] = [];
    let finalText = llmResponse.text;

    // 8. Execute any requested tool calls (bounded, permission-checked)
    const boundedToolCalls = llmResponse.toolCalls.slice(0, config.security.maxToolCallsPerTurn);
    for (const call of boundedToolCalls) {
      try {
        const result = await this.deps.toolExecutor.execute(
          call.name,
          call.input,
          { auth, conversationId: request.conversationId },
          ragResult.contextText
        );
        toolCallRecords.push({
          toolName: call.name,
          parameters: call.input,
          result: result.data,
          status: result.success ? 'executed' : 'failed',
          reason: result.error,
        });
        if (!result.success) flags.push('tool_execution_failed');
      } catch (err) {
        if (err instanceof UnauthorizedToolCallError) {
          toolCallRecords.push({
            toolName: call.name,
            parameters: call.input,
            status: 'rejected',
            reason: err.message,
          });
          flags.push('unauthorized_tool_blocked');
        } else {
          toolCallRecords.push({
            toolName: call.name,
            parameters: call.input,
            status: 'failed',
            reason: (err as Error).message,
          });
          flags.push('tool_execution_failed');
        }
      }
    }

    // If tools were called, feed their real results back so the final answer
    // reflects actual data rather than the model's unverified first draft.
    if (boundedToolCalls.length > 0) {
      const toolResultsPayload = toolCallRecords.map((r, i) => ({
        tool_use_id: llmResponse.toolCalls[i]?.id ?? `unknown-${i}`,
        content: JSON.stringify(r.status === 'executed' ? r.result : { error: r.reason }),
      }));
      const followUp = await this.deps.llmClient.continueWithToolResults(
        prompt.system,
        prompt.messages,
        buildAssistantToolUseContent(llmResponse),
        toolResultsPayload
      );
      finalText = followUp.text || finalText;
    }

    // 9. Output-side security scan (system prompt leakage)
    const outputScan = scanOutputForLeakage(finalText);
    flags.push(...outputScan.flags);
    if (!outputScan.safe) {
      finalText =
        "I can't share internal system details, but I'm happy to help with your question about the company otherwise.";
    }

    // 10. Response validation against retrieved context — reject/flag fabrications
    const validation = validateResponse(finalText, ragResult.chunks, ragResult.hasSufficientContext);
    if (!validation.passed) {
      flags.push('validation_rejected_claim');
      finalText = validation.sanitizedResponse ?? finalText;
    }

    // 11. Persist assistant turn to memory
    await this.deps.memoryManager.appendMessage(conversation, {
      role: 'assistant',
      content: finalText,
      timestamp: new Date().toISOString(),
    });

    const sources: SourceReference[] = ragResult.chunks.map((c) => ({
      documentId: c.documentId,
      documentName: String(c.metadata.fileName ?? c.documentId),
      chunkId: c.chunkId,
      score: c.score,
      excerpt: c.text.slice(0, 160),
    }));

    return {
      response: finalText,
      conversationId: request.conversationId,
      toolCalls: toolCallRecords,
      sources,
      confidence: computeConfidence(ragResult.hasSufficientContext, toolCallRecords, flags),
      flags: Array.from(new Set(flags)),
    };
  }
}

function computeConfidence(
  hasContext: boolean,
  toolCalls: ToolCallRecord[],
  flags: ResponseFlag[]
): ConfidenceLevel {
  if (flags.includes('validation_rejected_claim')) return 'low';
  const anyToolFailed = toolCalls.some((t) => t.status === 'failed' || t.status === 'rejected');
  if (anyToolFailed) return 'medium';
  if (!hasContext && toolCalls.length === 0) return 'unavailable';
  return hasContext ? 'high' : 'medium';
}

function buildAssistantToolUseContent(llmResponse: { text: string; toolCalls: { id: string; name: string; input: Record<string, unknown> }[] }) {
  const content: unknown[] = [];
  if (llmResponse.text) content.push({ type: 'text', text: llmResponse.text });
  for (const call of llmResponse.toolCalls) {
    content.push({ type: 'tool_use', id: call.id, name: call.name, input: call.input });
  }
  return content;
}
