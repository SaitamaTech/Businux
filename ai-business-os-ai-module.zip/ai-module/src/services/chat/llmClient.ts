/**
 * Thin wrapper around the Anthropic SDK so the rest of the chat pipeline
 * doesn't depend directly on the SDK's shapes.
 */

import Anthropic from '@anthropic-ai/sdk';
import { config } from '../../config';
import { ClaudeMessage } from '../../prompts/promptBuilder';
import { toClaudeToolFormat } from '../tools/toolRegistry';

export interface LlmToolCall {
  id: string;
  name: string;
  input: Record<string, unknown>;
}

export interface LlmResponse {
  text: string;
  toolCalls: LlmToolCall[];
  stopReason: string | null;
}

export class LlmClient {
  private client: Anthropic;

  constructor() {
    this.client = new Anthropic({ apiKey: config.llm.apiKey });
  }

  async generate(system: string, messages: ClaudeMessage[], allowTools: boolean): Promise<LlmResponse> {
    const response = await this.client.messages.create({
      model: config.llm.model,
      max_tokens: 1500,
      system,
      messages,
      tools: allowTools ? toClaudeToolFormat() : undefined,
    });

    const textParts: string[] = [];
    const toolCalls: LlmToolCall[] = [];

    for (const block of response.content) {
      if (block.type === 'text') {
        textParts.push(block.text);
      } else if (block.type === 'tool_use') {
        toolCalls.push({
          id: block.id,
          name: block.name,
          input: block.input as Record<string, unknown>,
        });
      }
    }

    return {
      text: textParts.join('\n'),
      toolCalls,
      stopReason: response.stop_reason,
    };
  }

  /** Continue a conversation after tool results are available (Claude tool-use loop). */
  async continueWithToolResults(
    system: string,
    messages: ClaudeMessage[],
    assistantToolUseContent: unknown,
    toolResults: { tool_use_id: string; content: string }[]
  ): Promise<LlmResponse> {
    const response = await this.client.messages.create({
      model: config.llm.model,
      max_tokens: 1500,
      system,
      messages: [
        ...messages,
        { role: 'assistant', content: assistantToolUseContent as never },
        {
          role: 'user',
          content: toolResults.map((r) => ({
            type: 'tool_result' as const,
            tool_use_id: r.tool_use_id,
            content: r.content,
          })) as never,
        },
      ],
    });

    const textParts: string[] = [];
    for (const block of response.content) {
      if (block.type === 'text') textParts.push(block.text);
    }
    return { text: textParts.join('\n'), toolCalls: [], stopReason: response.stop_reason };
  }
}
