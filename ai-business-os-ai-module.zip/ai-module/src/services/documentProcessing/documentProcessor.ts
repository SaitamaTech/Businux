/**
 * Document processing pipeline:
 * extract text -> clean -> chunk -> (embed + store happens in ragService)
 */

import { v4 as uuidv4 } from 'uuid';
import { config } from '../../config';
import { DocumentChunk, RawDocumentInput } from '../../types';

// pdf-parse and mammoth are required lazily so environments that only ever
// process txt/md don't need the native deps installed.
async function extractPdfText(buffer: Buffer): Promise<string> {
  const pdfParse = (await import('pdf-parse')).default;
  const result = await pdfParse(buffer);
  return result.text;
}

async function extractDocxText(buffer: Buffer): Promise<string> {
  const mammoth = await import('mammoth');
  const result = await mammoth.extractRawText({ buffer });
  return result.value;
}

function extractPlainText(buffer: Buffer): string {
  return buffer.toString('utf-8');
}

export async function extractText(doc: RawDocumentInput): Promise<string> {
  switch (doc.fileType) {
    case 'pdf':
      return extractPdfText(doc.buffer);
    case 'docx':
      return extractDocxText(doc.buffer);
    case 'txt':
    case 'md':
      return extractPlainText(doc.buffer);
    default:
      throw new Error(`Unsupported file type: ${doc.fileType}`);
  }
}

export function cleanText(raw: string): string {
  return raw
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Chunk text into overlapping windows on paragraph boundaries where possible,
 * falling back to hard character splits for very long paragraphs.
 */
export function chunkText(
  cleanedText: string,
  chunkSize: number = config.rag.chunkSize,
  overlap: number = config.rag.chunkOverlap
): string[] {
  const paragraphs = cleanedText.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
  const chunks: string[] = [];
  let current = '';

  const pushChunk = (text: string) => {
    const trimmed = text.trim();
    if (trimmed.length > 0) chunks.push(trimmed);
  };

  for (const paragraph of paragraphs) {
    if (paragraph.length > chunkSize) {
      // Hard split oversized paragraph
      if (current) {
        pushChunk(current);
        current = '';
      }
      for (let i = 0; i < paragraph.length; i += chunkSize - overlap) {
        pushChunk(paragraph.slice(i, i + chunkSize));
      }
      continue;
    }

    if ((current + '\n\n' + paragraph).length > chunkSize) {
      pushChunk(current);
      // start next chunk with overlap tail of previous chunk for continuity
      const tail = current.slice(Math.max(0, current.length - overlap));
      current = tail + '\n\n' + paragraph;
    } else {
      current = current ? current + '\n\n' + paragraph : paragraph;
    }
  }
  pushChunk(current);
  return chunks;
}

export async function processDocument(doc: RawDocumentInput): Promise<DocumentChunk[]> {
  const rawText = await extractText(doc);
  const cleaned = cleanText(rawText);
  const chunks = chunkText(cleaned);

  return chunks.map((text, index) => ({
    chunkId: uuidv4(),
    documentId: doc.documentId,
    companyId: doc.companyId,
    text,
    order: index,
    metadata: {
      fileName: doc.fileName,
      fileType: doc.fileType,
      uploadedBy: doc.uploadedBy,
    },
  }));
}
