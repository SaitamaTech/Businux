/**
 * Conversation memory manager.
 *
 * Handles short-term (in-conversation) memory today. Designed so a
 * `LongTermMemoryStore` can be added later (e.g. per-company user
 * preferences, recurring customers) without changing the public interface —
 * callers only ever talk to `MemoryManager`.
 *
 * `workingMemory` is deliberately generic (Record<string, unknown>) so tools
 * can stash structured state (e.g. "lastGeneratedQuotation") that later turns
 * can reference — this is what lets "add five extra items" resolve correctly
 * without re-parsing the whole transcript.
 */

import { ChatMessage, ConversationState } from '../../types';

const MAX_MESSAGES_IN_CONTEXT = 20; // sliding window to bound token usage

export interface ConversationStore {
  get(conversationId: string): Promise<ConversationState | null>;
  save(state: ConversationState): Promise<void>;
}

/**
 * In-memory store for the hackathon build. Swap for a Redis- or DB-backed
 * store in production (the DB module's job, not ours) by implementing
 * `ConversationStore`.
 */
export class InMemoryConversationStore implements ConversationStore {
  private store: Map<string, ConversationState> = new Map();

  async get(conversationId: string): Promise<ConversationState | null> {
    return this.store.get(conversationId) ?? null;
  }

  async save(state: ConversationState): Promise<void> {
    this.store.set(state.conversationId, state);
  }
}

export class MemoryManager {
  constructor(private store: ConversationStore = new InMemoryConversationStore()) {}

  async getOrCreate(
    conversationId: string,
    companyId: string,
    userId: string
  ): Promise<ConversationState> {
    const existing = await this.store.get(conversationId);
    if (existing) {
      // Defense in depth: never let a conversation be reused across companies.
      if (existing.companyId !== companyId) {
        throw new Error('Conversation/company mismatch — refusing cross-tenant memory access');
      }
      return existing;
    }
    const fresh: ConversationState = {
      conversationId,
      companyId,
      userId,
      messages: [],
      workingMemory: {},
      updatedAt: new Date().toISOString(),
    };
    await this.store.save(fresh);
    return fresh;
  }

  async appendMessage(state: ConversationState, message: ChatMessage): Promise<ConversationState> {
    const updated: ConversationState = {
      ...state,
      messages: [...state.messages, message],
      updatedAt: new Date().toISOString(),
    };
    await this.store.save(updated);
    return updated;
  }

  async setWorkingMemory(
    state: ConversationState,
    key: string,
    value: unknown
  ): Promise<ConversationState> {
    const updated: ConversationState = {
      ...state,
      workingMemory: { ...state.workingMemory, [key]: value },
      updatedAt: new Date().toISOString(),
    };
    await this.store.save(updated);
    return updated;
  }

  /** Recent messages, bounded, for inclusion in the prompt. */
  getRecentMessages(state: ConversationState, limit: number = MAX_MESSAGES_IN_CONTEXT): ChatMessage[] {
    return state.messages.slice(-limit);
  }
}
