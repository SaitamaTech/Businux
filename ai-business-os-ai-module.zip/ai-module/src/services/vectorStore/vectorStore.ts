/**
 * Vector store abstraction. Swap `InMemoryVectorStore` for a Pinecone /
 * pgvector / Qdrant-backed implementation later without touching RAG logic —
 * everything upstream only talks to the `VectorStore` interface.
 *
 * CRITICAL MULTI-TENANCY RULE: every query and every write is scoped by
 * companyId. There is no method on this interface that can return chunks
 * across companies. This is enforced structurally, not just by convention —
 * `search` and `deleteByDocument` both require companyId as a parameter and
 * the in-memory implementation partitions storage by companyId internally.
 */

import { EmbeddedChunk, RetrievedChunk } from '../../types';
import { cosineSimilarity } from '../embeddings/embeddingService';

export interface VectorStore {
  upsert(chunks: EmbeddedChunk[]): Promise<void>;
  search(companyId: string, queryEmbedding: number[], topK: number): Promise<RetrievedChunk[]>;
  deleteByDocument(companyId: string, documentId: string): Promise<void>;
}

export class InMemoryVectorStore implements VectorStore {
  // Partitioned by companyId at the top level -> structurally impossible to
  // accidentally search across tenants.
  private storeByCompany: Map<string, EmbeddedChunk[]> = new Map();

  async upsert(chunks: EmbeddedChunk[]): Promise<void> {
    for (const chunk of chunks) {
      const existing = this.storeByCompany.get(chunk.companyId) ?? [];
      existing.push(chunk);
      this.storeByCompany.set(chunk.companyId, existing);
    }
  }

  async search(
    companyId: string,
    queryEmbedding: number[],
    topK: number
  ): Promise<RetrievedChunk[]> {
    const companyChunks = this.storeByCompany.get(companyId) ?? [];
    const scored: RetrievedChunk[] = companyChunks.map((chunk) => ({
      ...chunk,
      score: cosineSimilarity(chunk.embedding, queryEmbedding),
    }));
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, topK);
  }

  async deleteByDocument(companyId: string, documentId: string): Promise<void> {
    const companyChunks = this.storeByCompany.get(companyId) ?? [];
    this.storeByCompany.set(
      companyId,
      companyChunks.filter((c) => c.documentId !== documentId)
    );
  }

  /** Test/debug helper only. */
  _debugCount(companyId: string): number {
    return (this.storeByCompany.get(companyId) ?? []).length;
  }
}

/**
 * Factory — reads config.vectorStore.provider. Real Pinecone/pgvector/Qdrant
 * adapters should implement `VectorStore` and be wired in here; they are not
 * implemented in this hackathon build since the choice of provider/infra is
 * a deployment decision, not an AI-logic decision.
 */
export function createVectorStore(): VectorStore {
  return new InMemoryVectorStore();
}
