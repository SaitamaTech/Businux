/**
 * Tool registry. Each tool declares name, description, parameter schema, and
 * (optionally) which roles may trigger it. The LLM is given this registry's
 * definitions (translated to Claude's tool-use format) and decides when to
 * call them — the registry itself does not decide anything, it only declares
 * capability + validates + dispatches to an executor.
 */

import { ToolDefinition } from '../../types';

export const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    name: 'generate_quotation',
    description:
      "Generate a price quotation for a customer using the company's real pricing catalog. Never guess prices — this tool must fail clearly if pricing data is unavailable.",
    parameters: {
      customerId: { type: 'string', description: 'ID of the customer, if known', required: false },
      customerName: { type: 'string', description: 'Name of the customer if no ID available', required: false },
      items: {
        type: 'array',
        description: 'Line items requested',
        required: true,
        items: {
          type: 'object',
          description: 'A single line item',
          properties: {
            sku: { type: 'string', description: 'Product/service SKU or name to look up in pricing catalog' },
            quantity: { type: 'number', description: 'Quantity requested' },
          },
        },
      },
    },
  },
  {
    name: 'generate_proposal',
    description:
      'Generate a business proposal document from company knowledge (services, past proposal templates) and the stated client needs.',
    parameters: {
      clientName: { type: 'string', description: 'Name of the prospective client', required: true },
      needsSummary: { type: 'string', description: 'Summary of what the client needs', required: true },
    },
  },
  {
    name: 'generate_invoice',
    description:
      'Generate an invoice for a customer based on real pricing and, if available, a prior quotation. Requires elevated permission (billing).',
    allowedRoles: ['owner', 'manager', 'billing'],
    parameters: {
      customerId: { type: 'string', description: 'ID of the customer being invoiced', required: true },
      items: {
        type: 'array',
        description: 'Line items to invoice',
        required: true,
        items: {
          type: 'object',
          description: 'A single line item',
          properties: {
            sku: { type: 'string', description: 'Product/service SKU' },
            quantity: { type: 'number', description: 'Quantity' },
          },
        },
      },
      dueDate: { type: 'string', description: 'ISO date the invoice is due', required: false },
    },
  },
  {
    name: 'generate_report',
    description: 'Generate a summary business report from retrieved company knowledge and/or data provided in the conversation.',
    parameters: {
      topic: { type: 'string', description: 'What the report should cover', required: true },
      period: { type: 'string', description: 'Reporting period, e.g. "Q1 2026"', required: false },
    },
  },
  {
    name: 'generate_maintenance_schedule',
    description: 'Generate a maintenance schedule from company equipment/asset knowledge and stated frequency requirements.',
    parameters: {
      assetName: { type: 'string', description: 'Name/identifier of the asset or equipment', required: true },
      frequency: { type: 'string', description: 'How often maintenance should occur, e.g. "monthly"', required: false },
    },
  },
  {
    name: 'summarize_document',
    description: 'Summarize a specific uploaded company document by ID.',
    parameters: {
      documentId: { type: 'string', description: 'ID of the document to summarize', required: true },
    },
  },
  {
    name: 'search_company_knowledge',
    description:
      'Explicitly search the company knowledge base for a specific fact when the main RAG pass did not already surface it.',
    parameters: {
      query: { type: 'string', description: 'What to search for', required: true },
    },
  },
  {
    name: 'create_task',
    description: 'Create a task/to-do in the business logic module.',
    parameters: {
      title: { type: 'string', description: 'Task title', required: true },
      description: { type: 'string', description: 'Task details', required: false },
      assigneeId: { type: 'string', description: 'User ID to assign the task to', required: false },
      dueDate: { type: 'string', description: 'ISO date the task is due', required: false },
    },
  },
  {
    name: 'schedule_meeting',
    description: 'Schedule a meeting in the business logic / calendar module.',
    parameters: {
      title: { type: 'string', description: 'Meeting title', required: true },
      attendees: { type: 'array', description: 'Attendee identifiers/emails', required: true, items: { type: 'string', description: 'attendee' } },
      startTime: { type: 'string', description: 'ISO start datetime', required: true },
      endTime: { type: 'string', description: 'ISO end datetime', required: true },
    },
  },
];

export function getToolDefinition(name: string): ToolDefinition | undefined {
  return TOOL_DEFINITIONS.find((t) => t.name === name);
}

/** Translate our internal schema into Claude's `tools` API input_schema format. */
export function toClaudeToolFormat() {
  return TOOL_DEFINITIONS.map((tool) => ({
    name: tool.name,
    description: tool.description,
    input_schema: {
      type: 'object' as const,
      properties: Object.fromEntries(
        Object.entries(tool.parameters).map(([key, schema]) => [key, toJsonSchema(schema)])
      ),
      required: Object.entries(tool.parameters)
        .filter(([, schema]) => schema.required)
        .map(([key]) => key),
    },
  }));
}

function toJsonSchema(schema: ToolDefinition['parameters'][string]): Record<string, unknown> {
  const base: Record<string, unknown> = {
    type: schema.type,
    description: schema.description,
  };
  if (schema.type === 'array' && schema.items) {
    base.items = toJsonSchema(schema.items);
  }
  if (schema.type === 'object' && schema.properties) {
    base.properties = Object.fromEntries(
      Object.entries(schema.properties).map(([k, v]) => [k, toJsonSchema(v)])
    );
  }
  return base;
}
