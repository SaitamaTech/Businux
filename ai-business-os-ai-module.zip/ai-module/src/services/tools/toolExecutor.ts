/**
 * Tool executor. Given a proposed tool call (name + parameters) from the LLM,
 * this:
 *  1. Verifies the tool exists.
 *  2. Verifies the requesting user's role is allowed to call it (permission check).
 *  3. Dispatches to the concrete implementation.
 *  4. Never fabricates a result if the implementation fails — always surfaces
 *     a clear success/failure instead of letting the LLM "guess" what happened.
 */

import { getToolDefinition } from './toolRegistry';
import {
  generateInvoice,
  generateMaintenanceSchedule,
  generateProposal,
  generateQuotation,
  generateReport,
} from './tools/documentGenerationTools';
import {
  createTask,
  scheduleMeeting,
  searchCompanyKnowledge,
  summarizeDocument,
} from './tools/operationalTools';
import { CompanyDataClient, BusinessLogicClient } from '../../api/externalClients';
import { RagService } from '../rag/ragService';
import { ToolExecutionContext, ToolExecutionResult } from '../../types';

export interface ToolExecutorDeps {
  companyDataClient: CompanyDataClient;
  businessLogicClient: BusinessLogicClient;
  ragService: RagService;
}

export class UnauthorizedToolCallError extends Error {}

export class ToolExecutor {
  constructor(private deps: ToolExecutorDeps) {}

  async execute(
    toolName: string,
    parameters: Record<string, unknown>,
    context: ToolExecutionContext,
    ragContextText: string = ''
  ): Promise<ToolExecutionResult> {
    const definition = getToolDefinition(toolName);
    if (!definition) {
      return { success: false, error: `Unknown tool: ${toolName}` };
    }

    if (definition.allowedRoles && definition.allowedRoles.length > 0) {
      if (!definition.allowedRoles.includes(context.auth.userRole)) {
        throw new UnauthorizedToolCallError(
          `Role "${context.auth.userRole}" is not permitted to call "${toolName}"`
        );
      }
    }

    const companyId = context.auth.companyId;

    switch (toolName) {
      case 'generate_quotation':
        return generateQuotation(
          companyId,
          parameters as { customerId?: string; customerName?: string; items: { sku: string; quantity: number }[] },
          this.deps.companyDataClient
        );

      case 'generate_invoice':
        return generateInvoice(
          companyId,
          parameters as { customerId: string; items: { sku: string; quantity: number }[]; dueDate?: string },
          this.deps.companyDataClient
        );

      case 'generate_proposal':
        return generateProposal({
          clientName: String(parameters.clientName),
          needsSummary: String(parameters.needsSummary),
          contextText: ragContextText,
        });

      case 'generate_report':
        return generateReport({
          topic: String(parameters.topic),
          period: parameters.period ? String(parameters.period) : undefined,
          contextText: ragContextText,
        });

      case 'generate_maintenance_schedule':
        return generateMaintenanceSchedule({
          assetName: String(parameters.assetName),
          frequency: parameters.frequency ? String(parameters.frequency) : undefined,
          contextText: ragContextText,
        });

      case 'search_company_knowledge':
        return searchCompanyKnowledge(companyId, String(parameters.query), this.deps.ragService);

      case 'summarize_document':
        return summarizeDocument(companyId, String(parameters.documentId), this.deps.ragService);

      case 'create_task':
        return createTask(
          companyId,
          parameters as { title: string; description?: string; assigneeId?: string; dueDate?: string },
          this.deps.businessLogicClient
        );

      case 'schedule_meeting':
        return scheduleMeeting(
          companyId,
          parameters as { title: string; attendees: string[]; startTime: string; endTime: string },
          this.deps.businessLogicClient
        );

      default:
        return { success: false, error: `Tool "${toolName}" has a definition but no executor wired up.` };
    }
  }
}
