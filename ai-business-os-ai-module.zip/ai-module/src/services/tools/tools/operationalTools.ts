/**
 * Implementations for search_company_knowledge, summarize_document,
 * create_task, and schedule_meeting.
 */

import { BusinessLogicClient, MeetingInput, TaskInput } from '../../../api/externalClients';
import { RagService } from '../../rag/ragService';
import { ToolExecutionResult } from '../../../types';

export async function searchCompanyKnowledge(
  companyId: string,
  query: string,
  ragService: RagService
): Promise<ToolExecutionResult> {
  const result = await ragService.retrieve(companyId, query);
  if (!result.hasSufficientContext) {
    return {
      success: true,
      data: { found: false, message: `No sufficiently relevant company knowledge found for "${query}".` },
    };
  }
  return {
    success: true,
    data: { found: true, contextText: result.contextText, sourceCount: result.chunks.length },
  };
}

export async function summarizeDocument(
  companyId: string,
  documentId: string,
  ragService: RagService
): Promise<ToolExecutionResult> {
  // Retrieve broadly from that document by using its ID as part of the query
  // context filter — a real implementation would add a documentId filter to
  // the vector store query; the in-memory store here filters client-side.
  const result = await ragService.retrieve(companyId, documentId, 20);
  const docChunks = result.chunks.filter((c) => c.documentId === documentId);
  if (docChunks.length === 0) {
    return { success: false, error: `Document ${documentId} not found or has no indexed content.` };
  }
  return {
    success: true,
    data: {
      documentId,
      chunkCount: docChunks.length,
      contextText: docChunks.map((c) => c.text).join('\n\n'),
    },
  };
}

export async function createTask(
  companyId: string,
  params: TaskInput,
  client: BusinessLogicClient
): Promise<ToolExecutionResult> {
  try {
    const result = await client.createTask(companyId, params);
    return { success: true, data: result };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}

export async function scheduleMeeting(
  companyId: string,
  params: MeetingInput,
  client: BusinessLogicClient
): Promise<ToolExecutionResult> {
  try {
    const result = await client.scheduleMeeting(companyId, params);
    return { success: true, data: result };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}
