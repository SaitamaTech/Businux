/**
 * Implementations for generate_quotation / generate_proposal / generate_invoice /
 * generate_report / generate_maintenance_schedule.
 *
 * Hard rule enforced here: these tools NEVER fabricate a price, customer, or
 * policy. If `CompanyDataClient` can't find something, the tool returns a
 * clear failure/gap rather than making a number up — the chat service turns
 * that into an honest "I don't have that information" response.
 */

import { CompanyDataClient, PricingItem } from '../../../api/externalClients';
import { ToolExecutionResult } from '../../../types';

interface RequestedLineItem {
  sku: string;
  quantity: number;
}

interface ResolvedLineItem extends RequestedLineItem {
  unitPrice: number;
  currency: string;
  lineTotal: number;
}

async function resolveLineItems(
  companyId: string,
  requested: RequestedLineItem[],
  dataClient: CompanyDataClient
): Promise<{ resolved: ResolvedLineItem[]; unresolved: string[] }> {
  const catalog: PricingItem[] = await dataClient.getPricingCatalog(companyId);
  const resolved: ResolvedLineItem[] = [];
  const unresolved: string[] = [];

  for (const item of requested) {
    const match = catalog.find(
      (p) => p.sku.toLowerCase() === item.sku.toLowerCase() || p.name.toLowerCase() === item.sku.toLowerCase()
    );
    if (!match) {
      unresolved.push(item.sku);
      continue;
    }
    resolved.push({
      ...item,
      unitPrice: match.unitPrice,
      currency: match.currency,
      lineTotal: match.unitPrice * item.quantity,
    });
  }
  return { resolved, unresolved };
}

export async function generateQuotation(
  companyId: string,
  params: { customerId?: string; customerName?: string; items: RequestedLineItem[] },
  dataClient: CompanyDataClient
): Promise<ToolExecutionResult> {
  const { resolved, unresolved } = await resolveLineItems(companyId, params.items, dataClient);

  if (unresolved.length > 0 && resolved.length === 0) {
    return {
      success: false,
      error: `None of the requested items (${unresolved.join(
        ', '
      )}) were found in the company pricing catalog. I can't generate a quotation with fabricated prices.`,
    };
  }

  const total = resolved.reduce((sum, i) => sum + i.lineTotal, 0);
  const currency = resolved[0]?.currency ?? 'USD';

  return {
    success: true,
    data: {
      customer: params.customerId ?? params.customerName ?? 'Unspecified customer',
      lineItems: resolved,
      unresolvedItems: unresolved,
      total,
      currency,
      generatedAt: new Date().toISOString(),
    },
  };
}

export async function generateInvoice(
  companyId: string,
  params: { customerId: string; items: RequestedLineItem[]; dueDate?: string },
  dataClient: CompanyDataClient
): Promise<ToolExecutionResult> {
  const customer = await dataClient.getCustomer(companyId, params.customerId);
  if (!customer) {
    return {
      success: false,
      error: `Customer ${params.customerId} was not found in company records. Cannot generate an invoice for an unknown customer.`,
    };
  }

  const { resolved, unresolved } = await resolveLineItems(companyId, params.items, dataClient);
  if (resolved.length === 0) {
    return {
      success: false,
      error: `None of the requested items (${unresolved.join(', ')}) were found in the pricing catalog.`,
    };
  }

  const total = resolved.reduce((sum, i) => sum + i.lineTotal, 0);
  const currency = resolved[0]?.currency ?? 'USD';

  return {
    success: true,
    data: {
      customer,
      lineItems: resolved,
      unresolvedItems: unresolved,
      total,
      currency,
      dueDate: params.dueDate,
      generatedAt: new Date().toISOString(),
    },
  };
}

/**
 * Proposal, report, and maintenance-schedule generation lean primarily on RAG
 * context (retrieved separately by the chat pipeline) rather than structured
 * pricing data. These tools format that context into a document skeleton;
 * the chat service is responsible for ensuring the retrieved context was
 * actually sufficient before calling them.
 */
export async function generateProposal(params: {
  clientName: string;
  needsSummary: string;
  contextText: string;
}): Promise<ToolExecutionResult> {
  if (!params.contextText || params.contextText.trim().length === 0) {
    return {
      success: false,
      error: 'No relevant company knowledge (services, past proposals) was found to build this proposal from.',
    };
  }
  return {
    success: true,
    data: {
      clientName: params.clientName,
      needsSummary: params.needsSummary,
      basedOnSources: true,
      generatedAt: new Date().toISOString(),
    },
  };
}

export async function generateReport(params: {
  topic: string;
  period?: string;
  contextText: string;
}): Promise<ToolExecutionResult> {
  if (!params.contextText || params.contextText.trim().length === 0) {
    return {
      success: false,
      error: `No company knowledge was found on "${params.topic}" to build this report from.`,
    };
  }
  return {
    success: true,
    data: {
      topic: params.topic,
      period: params.period,
      generatedAt: new Date().toISOString(),
    },
  };
}

export async function generateMaintenanceSchedule(params: {
  assetName: string;
  frequency?: string;
  contextText: string;
}): Promise<ToolExecutionResult> {
  if (!params.contextText || params.contextText.trim().length === 0) {
    return {
      success: false,
      error: `No company knowledge was found about "${params.assetName}" to build a maintenance schedule from.`,
    };
  }
  return {
    success: true,
    data: {
      assetName: params.assetName,
      frequency: params.frequency ?? 'Not specified — defaulted to manufacturer guidance in source material',
      generatedAt: new Date().toISOString(),
    },
  };
}
