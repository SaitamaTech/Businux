/**
 * Embedding service. Abstracted behind EmbeddingProvider so the vector model
 * (OpenAI, Voyage AI, etc.) can be swapped without touching RAG logic.
 *
 * Includes a deterministic local-mock provider so the whole pipeline can be
 * demoed and unit-tested without any external API key — useful during the
 * hackathon before real keys are wired in.
 */

import { config } from '../../config';

export interface EmbeddingProvider {
  embed(texts: string[]): Promise<number[][]>;
  dimensions: number;
}

/**
 * Deterministic hash-based "embedding" for local dev/testing.
 * NOT semantically meaningful — do not use in production. Its only job is to
 * let RAG plumbing (chunking → embed → store → retrieve → rank) be exercised
 * end-to-end without network calls.
 */
class LocalMockEmbeddingProvider implements EmbeddingProvider {
  dimensions = 64;

  async embed(texts: string[]): Promise<number[][]> {
    return texts.map((text) => this.hashToVector(text));
  }

  private hashToVector(text: string): number[] {
    const vec = new Array(this.dimensions).fill(0);
    const normalized = text.toLowerCase();
    for (let i = 0; i < normalized.length; i++) {
      const code = normalized.charCodeAt(i);
      vec[code % this.dimensions] += 1;
      vec[(code * 31) % this.dimensions] += 0.5;
    }
    // L2 normalize so cosine similarity behaves sensibly
    const norm = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0)) || 1;
    return vec.map((v) => v / norm);
  }
}

class OpenAIEmbeddingProvider implements EmbeddingProvider {
  dimensions = config.embeddings.dimensions;

  async embed(texts: string[]): Promise<number[][]> {
    const res = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.embeddings.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: config.embeddings.model,
        input: texts,
      }),
    });
    if (!res.ok) {
      throw new Error(`Embedding provider error: ${res.status} ${await res.text()}`);
    }
    const body = (await res.json()) as { data: { embedding: number[] }[] };
    return body.data.map((d) => d.embedding);
  }
}

function createProvider(): EmbeddingProvider {
  switch (config.embeddings.provider) {
    case 'openai':
      return new OpenAIEmbeddingProvider();
    case 'voyage':
      // Same shape as OpenAI's endpoint contract-wise; implement similarly
      // when a Voyage API key is available. Falls back to mock for now.
      // eslint-disable-next-line no-console
      console.warn('[embeddingService] Voyage provider not wired yet, using local mock');
      return new LocalMockEmbeddingProvider();
    case 'local-mock':
    default:
      return new LocalMockEmbeddingProvider();
  }
}

export class EmbeddingService {
  private provider: EmbeddingProvider;

  constructor(provider?: EmbeddingProvider) {
    this.provider = provider ?? createProvider();
  }

  async embedTexts(texts: string[]): Promise<number[][]> {
    if (texts.length === 0) return [];
    // Batch to stay under typical provider batch limits
    const batchSize = 100;
    const results: number[][] = [];
    for (let i = 0; i < texts.length; i += batchSize) {
      const batch = texts.slice(i, i + batchSize);
      const embeddings = await this.provider.embed(batch);
      results.push(...embeddings);
    }
    return results;
  }

  async embedQuery(text: string): Promise<number[]> {
    const [embedding] = await this.provider.embed([text]);
    return embedding;
  }

  get dimensions(): number {
    return this.provider.dimensions;
  }
}

export function cosineSimilarity(a: number[], b: number[]): number {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}
