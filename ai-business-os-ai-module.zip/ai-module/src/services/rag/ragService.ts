/**
 * Retrieval-Augmented Generation service.
 *
 * Responsible for:
 *  - Ingesting processed document chunks (embed + store)
 *  - Retrieving the most relevant chunks for a user query, scoped to a company
 *  - Building a bounded context string to insert into the prompt
 *
 * The AI must answer ONLY from retrieved information. `hasSufficientContext`
 * signals to the prompt builder / chat service when to say "I can't find that"
 * instead of guessing.
 */

import { config } from '../../config';
import { DocumentChunk, RagResult, RetrievedChunk } from '../../types';
import { EmbeddingService } from '../embeddings/embeddingService';
import { VectorStore } from '../vectorStore/vectorStore';

export class RagService {
  constructor(
    private embeddingService: EmbeddingService,
    private vectorStore: VectorStore
  ) {}

  async ingestChunks(chunks: DocumentChunk[]): Promise<void> {
    if (chunks.length === 0) return;
    const embeddings = await this.embeddingService.embedTexts(chunks.map((c) => c.text));
    const embeddedChunks = chunks.map((chunk, i) => ({ ...chunk, embedding: embeddings[i] }));
    await this.vectorStore.upsert(embeddedChunks);
  }

  async retrieve(
    companyId: string,
    query: string,
    topK: number = config.rag.topK
  ): Promise<RagResult> {
    const queryEmbedding = await this.embeddingService.embedQuery(query);
    const rawResults = await this.vectorStore.search(companyId, queryEmbedding, topK);

    const relevant = rawResults.filter((r) => r.score >= config.rag.minRelevanceScore);
    const hasSufficientContext = relevant.length > 0;

    const contextText = this.buildContextText(relevant.length > 0 ? relevant : rawResults);

    return {
      chunks: relevant.length > 0 ? relevant : rawResults,
      contextText,
      hasSufficientContext,
    };
  }

  private buildContextText(chunks: RetrievedChunk[]): string {
    if (chunks.length === 0) return '';
    return chunks
      .map(
        (c, i) =>
          `[Source ${i + 1} | doc:${c.documentId} | chunk:${c.chunkId} | relevance:${c.score.toFixed(
            2
          )}]\n${c.text}`
      )
      .join('\n\n---\n\n');
  }

  async deleteDocument(companyId: string, documentId: string): Promise<void> {
    await this.vectorStore.deleteByDocument(companyId, documentId);
  }
}
