import * as dotenv from 'dotenv';
dotenv.config();

function required(name: string, fallback?: string): string {
  const val = process.env[name] ?? fallback;
  if (val === undefined) {
    // In a hackathon/dev context we warn instead of crashing so the module
    // can still boot for tests that don't need every key (e.g. mocked LLM).
    // eslint-disable-next-line no-console
    console.warn(`[config] Missing environment variable: ${name}`);
    return '';
  }
  return val;
}

export const config = {
  llm: {
    apiKey: required('ANTHROPIC_API_KEY'),
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
  },
  embeddings: {
    provider: (process.env.EMBEDDING_PROVIDER || 'local-mock') as
      | 'openai'
      | 'voyage'
      | 'local-mock',
    apiKey: process.env.EMBEDDING_API_KEY || '',
    model: process.env.EMBEDDING_MODEL || 'text-embedding-3-small',
    dimensions: Number(process.env.EMBEDDING_DIMENSIONS || 1536),
  },
  vectorStore: {
    provider: (process.env.VECTOR_STORE_PROVIDER || 'in-memory') as
      | 'in-memory'
      | 'pinecone'
      | 'pgvector'
      | 'qdrant',
    url: process.env.VECTOR_STORE_URL || '',
    apiKey: process.env.VECTOR_STORE_API_KEY || '',
  },
  server: {
    port: Number(process.env.PORT || 4000),
    env: process.env.NODE_ENV || 'development',
  },
  security: {
    maxMessageLength: Number(process.env.MAX_MESSAGE_LENGTH || 8000),
    maxToolCallsPerTurn: Number(process.env.MAX_TOOL_CALLS_PER_TURN || 3),
    rateLimitPerMinute: Number(process.env.RATE_LIMIT_PER_MINUTE || 30),
  },
  externalServices: {
    authBaseUrl: process.env.AUTH_SERVICE_BASE_URL || '',
    dbBaseUrl: process.env.DB_SERVICE_BASE_URL || '',
    businessLogicBaseUrl: process.env.BUSINESS_LOGIC_SERVICE_BASE_URL || '',
  },
  rag: {
    chunkSize: 800, // characters
    chunkOverlap: 120,
    topK: 6,
    minRelevanceScore: 0.72,
  },
};
