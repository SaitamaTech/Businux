/**
 * These are CLIENT INTERFACES for modules owned by other team members
 * (auth, database, business logic, file storage). We define the contract and
 * a thin HTTP-calling stub, but never implement their internal logic.
 *
 * Swap the base URLs in .env once those services are live. Until then, these
 * throw a clear error rather than silently fabricating data — fabricating
 * company data (pricing, customers, policies) is explicitly forbidden by
 * the AI security rules for this module.
 */

import { config } from '../config';
import { AuthenticatedContext } from '../types';

export class NotImplementedByAIModuleError extends Error {
  constructor(moduleName: string) {
    super(
      `${moduleName} is owned by another team member and is not implemented here. ` +
        `This is a contract stub — wire it up to the real service via its base URL in .env`
    );
    this.name = 'NotImplementedByAIModuleError';
  }
}

// ---------------------------------------------------------------------------
// Auth module contract
// ---------------------------------------------------------------------------

export interface AuthClient {
  getUserContext(userId: string, companyId: string): Promise<AuthenticatedContext>;
  hasPermission(userId: string, companyId: string, permission: string): Promise<boolean>;
}

export class HttpAuthClient implements AuthClient {
  async getUserContext(userId: string, companyId: string): Promise<AuthenticatedContext> {
    if (!config.externalServices.authBaseUrl) {
      throw new NotImplementedByAIModuleError('Auth service');
    }
    const res = await fetch(
      `${config.externalServices.authBaseUrl}/internal/users/${userId}/context?companyId=${companyId}`
    );
    if (!res.ok) throw new Error(`Auth service error: ${res.status}`);
    return (await res.json()) as AuthenticatedContext;
  }

  async hasPermission(userId: string, companyId: string, permission: string): Promise<boolean> {
    if (!config.externalServices.authBaseUrl) {
      throw new NotImplementedByAIModuleError('Auth service');
    }
    const res = await fetch(
      `${config.externalServices.authBaseUrl}/internal/users/${userId}/permissions/${permission}?companyId=${companyId}`
    );
    if (!res.ok) return false;
    const body = await res.json();
    return Boolean((body as { allowed?: boolean }).allowed);
  }
}

// ---------------------------------------------------------------------------
// Database / company-data module contract
// ---------------------------------------------------------------------------

export interface CompanyProfile {
  companyId: string;
  name: string;
  industry?: string;
  policies?: Record<string, string>;
}

export interface PricingItem {
  sku: string;
  name: string;
  unitPrice: number;
  currency: string;
}

export interface Customer {
  customerId: string;
  name: string;
  email?: string;
}

export interface GeneratedDocumentRecord {
  type: 'quotation' | 'proposal' | 'invoice' | 'report';
  content: string;
  createdBy: string;
}

export interface CompanyDataClient {
  getCompanyProfile(companyId: string): Promise<CompanyProfile | null>;
  getPricingCatalog(companyId: string): Promise<PricingItem[]>;
  getCustomer(companyId: string, customerId: string): Promise<Customer | null>;
  saveGeneratedDocument(
    companyId: string,
    doc: GeneratedDocumentRecord
  ): Promise<{ id: string }>;
}

export class HttpCompanyDataClient implements CompanyDataClient {
  private base = config.externalServices.dbBaseUrl;

  async getCompanyProfile(companyId: string): Promise<CompanyProfile | null> {
    if (!this.base) throw new NotImplementedByAIModuleError('Database module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}`);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`DB service error: ${res.status}`);
    return (await res.json()) as CompanyProfile;
  }

  async getPricingCatalog(companyId: string): Promise<PricingItem[]> {
    if (!this.base) throw new NotImplementedByAIModuleError('Database module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}/pricing`);
    if (!res.ok) throw new Error(`DB service error: ${res.status}`);
    return (await res.json()) as PricingItem[];
  }

  async getCustomer(companyId: string, customerId: string): Promise<Customer | null> {
    if (!this.base) throw new NotImplementedByAIModuleError('Database module');
    const res = await fetch(
      `${this.base}/internal/companies/${companyId}/customers/${customerId}`
    );
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`DB service error: ${res.status}`);
    return (await res.json()) as Customer;
  }

  async saveGeneratedDocument(
    companyId: string,
    doc: GeneratedDocumentRecord
  ): Promise<{ id: string }> {
    if (!this.base) throw new NotImplementedByAIModuleError('Database module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}/documents`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc),
    });
    if (!res.ok) throw new Error(`DB service error: ${res.status}`);
    return (await res.json()) as { id: string };
  }
}

// ---------------------------------------------------------------------------
// Business logic module contract
// ---------------------------------------------------------------------------

export interface TaskInput {
  title: string;
  description?: string;
  assigneeId?: string;
  dueDate?: string;
}

export interface MeetingInput {
  title: string;
  attendees: string[];
  startTime: string;
  endTime: string;
}

export interface InvoiceInput {
  customerId: string;
  lineItems: { sku: string; quantity: number }[];
  dueDate?: string;
}

export interface BusinessLogicClient {
  createTask(companyId: string, task: TaskInput): Promise<{ id: string }>;
  scheduleMeeting(companyId: string, meeting: MeetingInput): Promise<{ id: string }>;
  createInvoiceRecord(
    companyId: string,
    invoice: InvoiceInput
  ): Promise<{ id: string; number: string }>;
}

export class HttpBusinessLogicClient implements BusinessLogicClient {
  private base = config.externalServices.businessLogicBaseUrl;

  async createTask(companyId: string, task: TaskInput): Promise<{ id: string }> {
    if (!this.base) throw new NotImplementedByAIModuleError('Business logic module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task),
    });
    if (!res.ok) throw new Error(`Business logic service error: ${res.status}`);
    return (await res.json()) as { id: string };
  }

  async scheduleMeeting(companyId: string, meeting: MeetingInput): Promise<{ id: string }> {
    if (!this.base) throw new NotImplementedByAIModuleError('Business logic module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}/meetings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(meeting),
    });
    if (!res.ok) throw new Error(`Business logic service error: ${res.status}`);
    return (await res.json()) as { id: string };
  }

  async createInvoiceRecord(
    companyId: string,
    invoice: InvoiceInput
  ): Promise<{ id: string; number: string }> {
    if (!this.base) throw new NotImplementedByAIModuleError('Business logic module');
    const res = await fetch(`${this.base}/internal/companies/${companyId}/invoices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(invoice),
    });
    if (!res.ok) throw new Error(`Business logic service error: ${res.status}`);
    return (await res.json()) as { id: string; number: string };
  }
}

// ---------------------------------------------------------------------------
// File storage module contract
// ---------------------------------------------------------------------------

export interface FileStorageClient {
  fetchFileBuffer(fileUrl: string): Promise<Buffer>;
}

export class HttpFileStorageClient implements FileStorageClient {
  async fetchFileBuffer(fileUrl: string): Promise<Buffer> {
    const res = await fetch(fileUrl);
    if (!res.ok) throw new Error(`Failed to fetch file: ${res.status}`);
    const arrayBuffer = await res.arrayBuffer();
    return Buffer.from(arrayBuffer);
  }
}
