import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { ChatService } from '../services/chat/chatService';
import { RagService } from '../services/rag/ragService';
import { processDocument } from '../services/documentProcessing/documentProcessor';
import { HttpFileStorageClient } from './externalClients';
import { RawDocumentInput, SupportedFileType } from '../types';

const chatRequestSchema = z.object({
  message: z.string().min(1),
  conversationId: z.string().min(1),
  companyId: z.string().min(1),
  userId: z.string().min(1),
});

const ingestRequestSchema = z.object({
  companyId: z.string().min(1),
  documentId: z.string().min(1),
  fileName: z.string().min(1),
  fileType: z.enum(['pdf', 'docx', 'txt', 'md']),
  fileUrl: z.string().url(),
  uploadedBy: z.string().min(1),
});

export function createRouter(chatService: ChatService, ragService: RagService): Router {
  const router = Router();
  const fileStorageClient = new HttpFileStorageClient();

  router.post('/api/chat', async (req: Request, res: Response) => {
    const parsed = chatRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid request body', details: parsed.error.flatten() });
    }
    try {
      const result = await chatService.handleMessage(parsed.data);
      return res.status(200).json(result);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('[chat] error', err);
      return res.status(500).json({ error: 'Failed to process chat message' });
    }
  });

  router.post('/api/documents/ingest', async (req: Request, res: Response) => {
    const parsed = ingestRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid request body', details: parsed.error.flatten() });
    }

    try {
      const buffer = await fileStorageClient.fetchFileBuffer(parsed.data.fileUrl);
      const docInput: RawDocumentInput = {
        companyId: parsed.data.companyId,
        documentId: parsed.data.documentId,
        fileName: parsed.data.fileName,
        fileType: parsed.data.fileType as SupportedFileType,
        buffer,
        uploadedBy: parsed.data.uploadedBy,
      };
      const chunks = await processDocument(docInput);
      await ragService.ingestChunks(chunks);
      return res.status(200).json({
        documentId: parsed.data.documentId,
        chunkCount: chunks.length,
        status: 'processed',
      });
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('[ingest] error', err);
      return res.status(200).json({
        documentId: parsed.data.documentId,
        chunkCount: 0,
        status: 'failed',
        error: (err as Error).message,
      });
    }
  });

  router.get('/health', (_req, res) => res.json({ status: 'ok' }));

  return router;
}
