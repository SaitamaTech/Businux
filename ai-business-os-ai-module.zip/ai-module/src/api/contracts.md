# Inter-Module API Contracts (Member 3 — AI Module)

This document defines every boundary between the AI module and the rest of the
AI Business OS. **Nothing described here as "owned by X" is implemented in this
repo.** These are the interfaces the AI module expects to call, or to be called
through. If an endpoint doesn't exist yet on another member's side, treat this
as the spec they should build against.

---

## 1. Inbound: Backend → AI Module

### `POST /api/chat` (this module exposes this)

Called by the main backend (owned by another member) after it has authenticated
the user and resolved `companyId`.

```ts
// Request body
{
  message: string;
  conversationId: string;
  companyId: string;
  userId: string;
}

// Response body
{
  response: string;
  conversationId: string;
  toolCalls: ToolCallRecord[];
  sources: SourceReference[];
  confidence: "high" | "medium" | "low" | "unavailable";
  flags?: string[];
}
```

The backend is responsible for:
- Verifying the JWT / session (auth module's job, not ours).
- Resolving `userId` → `companyId` and `userRole` (assumed available; if the
  main backend wants us to resolve it, add a `userRole` field to the request —
  see `AuthenticatedContext` in `src/types/index.ts`).
- Rate limiting at the network edge (we also do lightweight in-module limiting
  as defense in depth, not as the primary control).

### `POST /api/documents/ingest` (this module exposes this)

Called by the file-upload/storage module once a file has been stored (e.g. in
S3/GCS) and its metadata persisted in the database.

```ts
// Request body
{
  companyId: string;
  documentId: string;   // ID already created by the DB module
  fileName: string;
  fileType: "pdf" | "docx" | "txt" | "md";
  fileUrl: string;       // signed URL or internal path the AI module can fetch from
  uploadedBy: string;
}

// Response body
{
  documentId: string;
  chunkCount: number;
  status: "processed" | "failed";
  error?: string;
}
```

---

## 2. Outbound: AI Module → Other Modules

These are calls the AI module makes OUT to other members' services. The AI
module treats all of them as black boxes behind a typed client interface, so
swapping the real implementation in later requires zero changes to AI logic.

### 2.1 Auth Module (owned by another member)

```ts
interface AuthClient {
  getUserContext(userId: string, companyId: string): Promise<AuthenticatedContext>;
  hasPermission(userId: string, companyId: string, permission: string): Promise<boolean>;
}
```
Expected base URL: `AUTH_SERVICE_BASE_URL` (see `.env.example`).
We call this before executing any sensitive tool (e.g. generating an invoice)
to confirm the requesting user is actually allowed to do so for that company.

### 2.2 Database Module (owned by another member)

```ts
interface CompanyDataClient {
  getCompanyProfile(companyId: string): Promise<CompanyProfile>;
  getPricingCatalog(companyId: string): Promise<PricingItem[]>;
  getCustomer(companyId: string, customerId: string): Promise<Customer | null>;
  saveGeneratedDocument(companyId: string, doc: GeneratedDocumentRecord): Promise<{ id: string }>;
}
```
Expected base URL: `DB_SERVICE_BASE_URL`.
The AI module NEVER invents pricing, customer records, or company profile
data — it always calls out to this client and, if the client returns nothing,
the tool must report "information not found" rather than fabricate a value.

### 2.3 Business Logic Module (owned by another member)

```ts
interface BusinessLogicClient {
  createTask(companyId: string, task: TaskInput): Promise<{ id: string }>;
  scheduleMeeting(companyId: string, meeting: MeetingInput): Promise<{ id: string }>;
  createInvoiceRecord(companyId: string, invoice: InvoiceInput): Promise<{ id: string; number: string }>;
}
```
Expected base URL: `BUSINESS_LOGIC_SERVICE_BASE_URL`.
Tools like `create_task` or `schedule_meeting` are thin wrappers that validate
parameters, then call this client. The AI module does not own task/meeting
business rules (recurrence, notifications, etc.) — only the natural-language
→ structured-parameters translation and the decision of *when* to call it.

### 2.4 Storage / File Retrieval (owned by another member)

```ts
interface FileStorageClient {
  fetchFileBuffer(fileUrl: string): Promise<Buffer>;
}
```
Used by the document ingestion pipeline to pull the raw bytes referenced by
`fileUrl` in the `/api/documents/ingest` payload.

---

## 3. Where the mock clients live

Until the real modules exist, `src/services/*` depend only on the *interfaces*
above (see `src/types/index.ts` and the per-service `*.client.ts` stub files).
Each stub throws a clear `NotImplementedByAIModuleError` explaining that the
real implementation belongs to another team member — this makes integration
gaps obvious during the hackathon demo instead of silently returning fake data.
