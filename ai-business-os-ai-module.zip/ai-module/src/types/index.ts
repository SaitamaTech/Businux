/**
 * Shared types for the AI module.
 *
 * These types define the CONTRACT between this module and the rest of the
 * AI Business OS. Other members' modules (auth, database, dashboard, business
 * logic) are expected to send/receive data shaped like this. We never implement
 * those modules ourselves — only the shapes we expect from / return to them.
 */

// ---------------------------------------------------------------------------
// Identity & tenancy (provided BY the auth/backend module, consumed by us)
// ---------------------------------------------------------------------------

/** Passed in on every request. Assumed to already be authenticated upstream. */
export interface AuthenticatedContext {
  userId: string;
  companyId: string; // used for strict multi-tenant isolation
  userRole: string; // e.g. "owner" | "manager" | "staff" — used for permission checks
  permissions?: string[]; // optional fine-grained permission list from auth module
}

// ---------------------------------------------------------------------------
// Chat API contract
// ---------------------------------------------------------------------------

export interface ChatRequest {
  message: string;
  conversationId: string;
  companyId: string;
  userId: string;
}

export interface ToolCallRecord {
  toolName: string;
  parameters: Record<string, unknown>;
  result?: unknown;
  status: 'proposed' | 'executed' | 'rejected' | 'failed';
  reason?: string;
}

export interface SourceReference {
  documentId: string;
  documentName: string;
  chunkId: string;
  score: number;
  excerpt: string; // short, truncated excerpt only — never the full chunk
}

export type ConfidenceLevel = 'high' | 'medium' | 'low' | 'unavailable';

export interface ChatResponse {
  response: string;
  conversationId: string;
  toolCalls: ToolCallRecord[];
  sources: SourceReference[];
  confidence: ConfidenceLevel;
  flags?: ResponseFlag[];
}

export type ResponseFlag =
  | 'no_knowledge_found'
  | 'validation_rejected_claim'
  | 'prompt_injection_detected'
  | 'unauthorized_tool_blocked'
  | 'tool_execution_failed';

// ---------------------------------------------------------------------------
// Conversation memory
// ---------------------------------------------------------------------------

export type ChatRole = 'user' | 'assistant' | 'system' | 'tool';

export interface ChatMessage {
  role: ChatRole;
  content: string;
  timestamp: string;
  toolName?: string; // set when role === 'tool'
}

export interface ConversationState {
  conversationId: string;
  companyId: string;
  userId: string;
  messages: ChatMessage[];
  /** Lightweight structured memory extracted from the conversation, e.g.
   *  the last generated document, so follow-ups like "add 5 more items"
   *  can be resolved without replaying the whole transcript. */
  workingMemory: Record<string, unknown>;
  updatedAt: string;
}

// ---------------------------------------------------------------------------
// Document processing & RAG
// ---------------------------------------------------------------------------

export type SupportedFileType = 'pdf' | 'docx' | 'txt' | 'md';

export interface RawDocumentInput {
  companyId: string;
  documentId: string;
  fileName: string;
  fileType: SupportedFileType;
  buffer: Buffer;
  uploadedBy: string;
}

export interface DocumentChunk {
  chunkId: string;
  documentId: string;
  companyId: string;
  text: string;
  order: number;
  metadata: Record<string, unknown>;
}

export interface EmbeddedChunk extends DocumentChunk {
  embedding: number[];
}

export interface RetrievedChunk extends DocumentChunk {
  score: number;
}

export interface RagResult {
  chunks: RetrievedChunk[];
  contextText: string;
  hasSufficientContext: boolean;
}

// ---------------------------------------------------------------------------
// Tool calling
// ---------------------------------------------------------------------------

export interface ToolParameterSchema {
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description: string;
  required?: boolean;
  items?: ToolParameterSchema; // for arrays
  properties?: Record<string, ToolParameterSchema>; // for objects
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, ToolParameterSchema>;
  /** Which roles are allowed to trigger this tool. Empty/undefined = any authenticated user. */
  allowedRoles?: string[];
}

export interface ToolExecutionContext {
  auth: AuthenticatedContext;
  conversationId: string;
}

export interface ToolExecutionResult {
  success: boolean;
  data?: unknown;
  error?: string;
}

// ---------------------------------------------------------------------------
// Response validation
// ---------------------------------------------------------------------------

export interface ValidationIssue {
  type: 'unsupported_claim' | 'fabricated_number' | 'fabricated_price' | 'fabricated_policy' | 'other';
  detail: string;
}

export interface ValidationResult {
  passed: boolean;
  issues: ValidationIssue[];
  sanitizedResponse?: string;
}

// ---------------------------------------------------------------------------
// Security
// ---------------------------------------------------------------------------

export interface SecurityScanResult {
  safe: boolean;
  flags: ResponseFlag[];
  sanitizedInput?: string;
  reason?: string;
}
